---
name: iterm-control
description: Control iTerm terminal instances via AppleScript for macOS. Use when managing multiple terminal sessions, running parallel dev servers (frontend/backend), monitoring command outputs, writing files efficiently, or automating iTerm window/tab operations. Enables opening terminals, executing commands, creating files, reading output, and coordinating multiple simultaneous processes.
---

# iTerm Control

Control iTerm terminal instances programmatically via AppleScript on macOS.

## Overview

This skill provides utilities to automate iTerm terminal operations through AppleScript. Use it to manage multiple terminal sessions, run commands in parallel, monitor outputs, and coordinate complex development workflows that require multiple simultaneous processes.

**Platform:** macOS only (requires iTerm and AppleScript)

## When to Use This Skill

Trigger this skill when:
- Running multiple development servers simultaneously (frontend + backend + database)
- Monitoring command outputs from long-running processes
- Automating terminal workflows that require multiple tabs or windows
- Coordinating parallel processes in separate terminal sessions
- Setting up development environments with predefined command sequences
- Creating files efficiently with iTerm session feedback (avoids shell escaping issues)

## Quick Start

### Basic Terminal Control

Open a terminal and execute a command:

```javascript
import { openTerminal, executeCommand } from './scripts/iterm_control.js';

// Open new terminal tab
await openTerminal("Dev server starting");

// Execute command in current session
await executeCommand("npm run dev");
```

### CLI Usage

Use the scripts directly from command line:

```bash
# Open new terminal
node scripts/iterm_control.js open "Ready for development"

# Execute command
node scripts/iterm_control.js execute "npm install"

# Write file efficiently
node scripts/iterm_control.js write memo.txt "Content here"
echo "Large content" | node scripts/iterm_control.js write output.txt --stdin

# Read session output
node scripts/iterm_control.js read

# Close current window
node scripts/iterm_control.js close
```

## Core Operations

### Opening Terminals

Create new terminal tabs or windows with optional initialization messages:

```javascript
await openTerminal("Backend server");
await executeCommand("cd backend && npm run dev");
```

**CLI:**
```bash
node scripts/iterm_control.js open "Starting service"
```

### Executing Commands

Run commands in the current iTerm session. Commands are automatically escaped for AppleScript compatibility:

```javascript
await executeCommand("npm run test");
await executeCommand("docker-compose up -d");
```

**CLI:**
```bash
node scripts/iterm_control.js execute "git status"
```

### Managing Multiple Terminals

Use `multi_terminal.js` to create coordinated terminal sessions:

**From Config File:**

Create `dev-config.json`:
```json
{
  "terminals": [
    {"name": "Frontend", "command": "cd frontend && npm run dev"},
    {"name": "Backend", "command": "cd backend && npm run dev"},
    {"name": "Logs", "command": "tail -f logs/app.log"}
  ]
}
```

Run:
```bash
node scripts/multi_terminal.js start dev-config.json
```

**Quick Commands:**
```bash
node scripts/multi_terminal.js run "npm run dev" "npm run test:watch" "tail -f app.log"
```

This creates a new iTerm window with multiple tabs, each running a different command.

### Reading Session Output

Retrieve text from the current terminal session:

```javascript
const output = await getSessionText();
console.log(output);
```

**CLI:**
```bash
node scripts/iterm_control.js read
```

### Writing Files Efficiently

Create files with content and get iTerm feedback. This method is much faster and more reliable than using heredoc or echo commands, especially for large files:

```javascript
import { writeFile } from './scripts/iterm_control.js';

// Write file with automatic iTerm notification
await writeFile('output.txt', content, {
  showInTerminal: true,   // Show notification in iTerm
  showPreview: true,      // Display file preview
  previewLines: 10        // Number of preview lines
});
```

**CLI (simple content):**
```bash
node scripts/iterm_control.js write memo.txt "File content here"
```

**CLI (large content via stdin):**
```bash
cat << 'EOF' | node scripts/iterm_control.js write output.txt --stdin
Large multi-line content
with special characters
and no escaping issues
EOF
```

**Benefits:**
- ⚡ Much faster than heredoc methods
- ✅ No size limitations
- ✅ Automatic handling of special characters and quotes
- ✅ iTerm session feedback and file preview
- ✅ Works with any file size or content type

## Available Scripts

### `iterm_control.js`
Core iTerm automation utilities.

**Functions:**
- `openTerminal(message)` - Open new terminal tab
- `executeCommand(command)` - Execute command in current session
- `closeTerminal()` - Close current window
- `getSessionText()` - Read session output
- `writeFile(path, content, options)` - Write file efficiently with iTerm feedback
- `saveTabs(backupFile)` - Save all current tabs to JSON file
- `restoreTabs(backupFile)` - Restore tabs from JSON backup
- `executeITermScript(script)` - Execute custom AppleScript

**CLI Commands:**
- `open [message]` - Open terminal
- `execute <command>` - Run command
- `read` - Get session text
- `write <path> <content>` - Write file with content
- `write <path> --stdin` - Write file from stdin (for large content)
- `save-tabs [file]` - Save current tabs (default: ~/.iterm_tabs_backup.json)
- `restore-tabs [file]` - Restore saved tabs
- `close` - Close window

### `multi_terminal.js`
Manage multiple terminal sessions simultaneously.

**Functions:**
- `createMultiTerminalWindow(terminals)` - Create window with multiple tabs
- `runCommandsInTabs(commands)` - Quick parallel command execution

**CLI Commands:**
- `start <config.json>` - Load terminals from config
- `run <cmd1> <cmd2> ...` - Run commands in parallel tabs

### `example-config.json`
Template configuration showing multi-terminal setup structure.

## Common Workflows

### Parallel Development Servers

Start frontend, backend, and database simultaneously:

```bash
node scripts/multi_terminal.js run \
  "cd frontend && npm run dev" \
  "cd backend && npm run dev" \
  "docker-compose up postgres"
```

### Development Environment Setup

Create config for your project:

```json
{
  "terminals": [
    {"name": "API", "command": "cd api && npm run dev"},
    {"name": "Web", "command": "cd web && npm start"},
    {"name": "Tests", "command": "npm run test:watch"},
    {"name": "Logs", "command": "tail -f logs/combined.log"}
  ]
}
```

Save as `dev-setup.json` and run:
```bash
node scripts/multi_terminal.js start dev-setup.json
```

### Monitoring and Automation

Programmatically control terminals for complex workflows:

```javascript
import { openTerminal, executeCommand, getSessionText } from './scripts/iterm_control.js';

// Start build process
await openTerminal("Build monitor");
await executeCommand("npm run build");

// Wait and check output
await new Promise(resolve => setTimeout(resolve, 5000));
const output = await getSessionText();

if (output.includes("Build successful")) {
  console.log("✅ Build completed successfully");
}
```

### Efficient File Creation

Create files with large content efficiently:

```javascript
import { writeFile } from './scripts/iterm_control.js';

// Generate report or analysis
const reportContent = generateSystemReport();

// Write to file with iTerm feedback
await writeFile('system-report.txt', reportContent, {
  showInTerminal: true,
  showPreview: true,
  previewLines: 15
});
```

**CLI Example:**
```bash
# Generate and save fastfetch output
fastfetch > /tmp/system.txt
cat /tmp/system.txt | node scripts/iterm_control.js write system-analysis.txt --stdin
```

### Tab Session Save and Restore

Save and restore your iTerm tabs to quickly recreate your workspace:

**Save Current Tabs:**
```bash
# Save to default location (~/.iterm_tabs_backup.json)
node scripts/iterm_control.js save-tabs

# Save to custom file
node scripts/iterm_control.js save-tabs my-workspace.json
```

**Restore Tabs:**
```bash
# Restore from default backup
node scripts/iterm_control.js restore-tabs

# Restore from custom file
node scripts/iterm_control.js restore-tabs my-workspace.json
```

**Programmatic Usage:**
```javascript
import { saveTabs, restoreTabs } from './scripts/iterm_control.js';

// Save current session
await saveTabs('~/my-projects/dev-workspace.json');

// Later, restore it
await restoreTabs('~/my-projects/dev-workspace.json');
```

**What Gets Saved:**
- Tab directory (working directory)
- Tab name
- Timestamp

**Use Cases:**
- Save your development workspace and restore after reboot
- Create different workspace configurations for different projects
- Quickly switch between multiple workspace layouts
- Backup your terminal setup

### Custom AppleScript Integration

Execute custom AppleScript for advanced control:

```javascript
import { executeITermScript } from './scripts/iterm_control.js';

const customScript = `
tell application "iTerm"
  tell current session of current window
    set name to "Custom Session"
    write text "echo 'Custom automation'"
  end tell
end tell
`;

await executeITermScript(customScript);
```

## Technical Notes

**AppleScript Compatibility:**
- Scripts automatically replace `iTerm2` references with `iTerm` for compatibility
- Commands are escaped to handle quotes and special characters
- Brief delays are included for iTerm activation and command execution

**Platform Requirements:**
- macOS only
- iTerm must be installed
- AppleScript must be enabled

**Error Handling:**
- All operations include try-catch blocks
- Errors are logged with descriptive messages
- CLI commands exit with appropriate status codes

**Process Management:**
- Each script execution is independent
- No persistent state between CLI invocations
- For state management, use as Node.js module

## Extending the Skill

Add custom iTerm operations by creating new scripts in `scripts/` or extending existing utilities. All functions use the base `executeITermScript()` for AppleScript execution, making it easy to add new automation capabilities.

Example custom operation:

```javascript
async function splitPaneVertically() {
  const script = `
  tell application "iTerm"
    tell current session of current window
      split vertically with default profile
    end tell
  end tell
  `;
  await executeITermScript(script);
}
```
