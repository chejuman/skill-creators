#!/usr/bin/env node

/**
 * iTerm Control Script
 *
 * Provides utilities to control iTerm terminal instances via AppleScript.
 * Can be used standalone or as a helper for Claude Code workflows.
 *
 * Usage:
 *   node iterm_control.js open [message]
 *   node iterm_control.js execute <command> [terminalId]
 *   node iterm_control.js close
 *
 * Examples:
 *   node iterm_control.js open "Starting dev server"
 *   node iterm_control.js execute "npm run dev"
 *   node iterm_control.js close
 */

import { exec } from "node:child_process";
import { promisify } from "node:util";

const execPromise = promisify(exec);

/**
 * Execute AppleScript to control iTerm
 */
async function executeITermScript(script) {
  const launchScript = `
  tell application "iTerm"
    activate
  end tell
  `;

  try {
    // Launch/activate iTerm
    const escapedLaunchScript = launchScript.replace(/'/g, "'\\''");
    await execPromise(`osascript -e '${escapedLaunchScript}'`);

    // Wait briefly for iTerm to be ready
    await new Promise((resolve) => setTimeout(resolve, 500));

    // Execute the actual script
    const modifiedScript = script.replace(/iTerm2/g, "iTerm");
    // Properly escape single quotes for shell
    const escapedScript = modifiedScript.replace(/'/g, "'\\''");
    const { stdout } = await execPromise(`osascript -e '${escapedScript}'`);
    return stdout.trim();
  } catch (error) {
    console.error("iTerm AppleScript error:", error.message);
    throw error;
  }
}

/**
 * Open a new iTerm terminal window/tab
 */
async function openTerminal(message = "Terminal ready") {
  // Escape backslashes and double quotes for AppleScript string literal
  const escapedMessage = message.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  const script = `
  tell application "iTerm"
    activate
    if (count of windows) = 0 then
      create window with default profile
    else
      tell current window
        create tab with default profile
      end tell
    end if
    tell current session of current window
      write text "echo \\"${escapedMessage}\\""
    end tell
  end tell
  `;

  try {
    await executeITermScript(script);
    console.log("✅ Terminal opened successfully");
    return true;
  } catch (error) {
    console.error("❌ Failed to open terminal:", error.message);
    return false;
  }
}

/**
 * Execute a command in the current iTerm session
 */
async function executeCommand(command) {
  // Escape backslashes and double quotes for AppleScript string literal
  const escapedCommand = command.replace(/\\/g, '\\\\').replace(/"/g, '\\"');

  const script = `
  tell application "iTerm"
    tell current session of current window
      write text "${escapedCommand}"
    end tell
  end tell
  `;

  try {
    await executeITermScript(script);
    console.log(`✅ Command executed: ${command}`);
    return true;
  } catch (error) {
    console.error("❌ Failed to execute command:", error.message);
    return false;
  }
}

/**
 * Close the current iTerm window
 */
async function closeTerminal() {
  const script = `
  tell application "iTerm"
    close current window
  end tell
  `;

  try {
    await executeITermScript(script);
    console.log("✅ Terminal closed successfully");
    return true;
  } catch (error) {
    console.error("❌ Failed to close terminal:", error.message);
    return false;
  }
}

/**
 * Get current iTerm session text
 */
async function getSessionText() {
  const script = `
  tell application "iTerm"
    tell current session of current window
      get text
    end tell
  end tell
  `;

  try {
    const output = await executeITermScript(script);
    return output;
  } catch (error) {
    console.error("❌ Failed to get session text:", error.message);
    return null;
  }
}

/**
 * Write content to a file efficiently and notify via iTerm
 * @param {string} filePath - Absolute or relative path to the file
 * @param {string} content - Content to write to the file
 * @param {Object} options - Optional configuration
 * @param {boolean} options.showInTerminal - Show notification in iTerm (default: true)
 * @param {boolean} options.showPreview - Show file preview in iTerm (default: true)
 * @param {number} options.previewLines - Number of lines to preview (default: 10)
 */
async function writeFile(filePath, content, options = {}) {
  const fs = await import("fs/promises");
  const path = await import("path");

  // Default options
  const opts = {
    showInTerminal: options.showInTerminal !== false,
    showPreview: options.showPreview !== false,
    previewLines: options.previewLines || 10,
  };

  try {
    // Write file locally (fast and reliable)
    await fs.writeFile(filePath, content, "utf-8");

    // Get file stats
    const stats = await fs.stat(filePath);
    const sizeKB = (stats.size / 1024).toFixed(2);
    const fileName = path.basename(filePath);
    const absolutePath = path.resolve(filePath);

    console.log(`✅ File written successfully: ${absolutePath}`);
    console.log(`   Size: ${sizeKB} KB`);

    // Notify in iTerm
    if (opts.showInTerminal) {
      await executeCommand(`echo "📝 파일 생성 완료: ${fileName} (${sizeKB} KB)"`);
      await executeCommand(`ls -lh "${absolutePath}"`);

      if (opts.showPreview) {
        await executeCommand(`echo "--- 파일 미리보기 (첫 ${opts.previewLines}줄) ---"`);
        await executeCommand(`head -n ${opts.previewLines} "${absolutePath}"`);
        await executeCommand(`echo "---"`);
      }
    }

    return { success: true, path: absolutePath, size: stats.size };
  } catch (error) {
    console.error("❌ Failed to write file:", error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Save all current iTerm tabs information
 * @param {string} backupFile - Path to save tabs information (default: ~/.iterm_tabs_backup.json)
 */
async function saveTabs(backupFile = null) {
  const fs = await import("fs/promises");
  const os = await import("os");
  const path = await import("path");

  const defaultBackupFile = path.join(os.homedir(), ".iterm_tabs_backup.json");
  const saveFile = backupFile || defaultBackupFile;

  const script = `
  set output to ""
  tell application "iTerm"
    repeat with aWindow in windows
      repeat with aTab in tabs of aWindow
        tell current session of aTab
          set tabName to name
          set tabPath to ""
          try
            set tabPath to variable named "session.path"
          end try
          set output to output & tabName & "|" & tabPath & "\\n"
        end tell
      end repeat
    end repeat
  end tell
  return output
  `;

  try {
    const tabsData = await executeITermScript(script);

    // Parse the tab data
    const tabs = [];
    const lines = tabsData.trim().split("\n");

    for (const line of lines) {
      if (line) {
        const [name, directory] = line.split("|");
        tabs.push({
          name: name || "Terminal",
          directory: directory || os.homedir(),
          timestamp: new Date().toISOString()
        });
      }
    }

    // Save to file
    await fs.writeFile(saveFile, JSON.stringify(tabs, null, 2), "utf-8");

    console.log(`✅ Saved ${tabs.length} tabs to ${saveFile}`);
    return { success: true, count: tabs.length, file: saveFile };
  } catch (error) {
    console.error("❌ Failed to save tabs:", error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Restore iTerm tabs from backup file
 * @param {string} backupFile - Path to tabs backup file (default: ~/.iterm_tabs_backup.json)
 */
async function restoreTabs(backupFile = null) {
  const fs = await import("fs/promises");
  const os = await import("os");
  const path = await import("path");

  const defaultBackupFile = path.join(os.homedir(), ".iterm_tabs_backup.json");
  const loadFile = backupFile || defaultBackupFile;

  try {
    // Read backup file
    const data = await fs.readFile(loadFile, "utf-8");
    const tabs = JSON.parse(data);

    console.log(`📂 Restoring ${tabs.length} tabs from ${loadFile}...`);

    // Create tabs
    for (let i = 0; i < tabs.length; i++) {
      const tab = tabs[i];

      const script = `
      tell application "iTerm"
        activate
        if (count of windows) = 0 then
          create window with default profile
        else
          if ${i} > 0 then
            tell current window
              create tab with default profile
            end tell
          end if
        end if
        tell current session of current window
          write text "cd \\"${tab.directory.replace(/"/g, '\\"')}\\""
          ${tab.name && tab.name !== "Terminal" ? `set name to "${tab.name.replace(/"/g, '\\"')}"` : ''}
        end tell
      end tell
      `;

      await executeITermScript(script);

      // Brief delay between tabs
      await new Promise(resolve => setTimeout(resolve, 300));
    }

    console.log(`✅ Restored ${tabs.length} tabs successfully`);
    return { success: true, count: tabs.length };
  } catch (error) {
    console.error("❌ Failed to restore tabs:", error.message);
    return { success: false, error: error.message };
  }
}

// CLI interface
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case "open":
      const message = args[1] || "Terminal ready";
      await openTerminal(message);
      break;

    case "execute":
    case "exec":
      if (!args[1]) {
        console.error("❌ Error: Command required");
        console.log("Usage: node iterm_control.js execute <command>");
        process.exit(1);
      }
      await executeCommand(args[1]);
      break;

    case "close":
      await closeTerminal();
      break;

    case "read":
    case "get":
      const text = await getSessionText();
      if (text) {
        console.log("📄 Session output:");
        console.log(text);
      }
      break;

    case "write":
    case "writefile":
      if (!args[1] || !args[2]) {
        console.error("❌ Error: File path and content required");
        console.log("Usage: node iterm_control.js write <filepath> <content>");
        console.log("   Or: node iterm_control.js write <filepath> --stdin  (read from stdin)");
        process.exit(1);
      }

      let fileContent;
      if (args[2] === "--stdin") {
        // Read from stdin for large content
        const chunks = [];
        for await (const chunk of process.stdin) {
          chunks.push(chunk);
        }
        fileContent = Buffer.concat(chunks).toString("utf-8");
      } else {
        fileContent = args.slice(2).join(" ");
      }

      await writeFile(args[1], fileContent);
      break;

    case "save-tabs":
    case "savetabs":
      const saveFile = args[1];
      await saveTabs(saveFile);
      break;

    case "restore-tabs":
    case "restoretabs":
      const restoreFile = args[1];
      await restoreTabs(restoreFile);
      break;

    default:
      console.log(`
iTerm Control Script

Usage:
  node iterm_control.js open [message]          - Open new terminal with optional message
  node iterm_control.js execute <command>       - Execute command in current session
  node iterm_control.js read                    - Read current session text
  node iterm_control.js write <path> <content>  - Write content to file and notify in iTerm
  node iterm_control.js save-tabs [file]        - Save all current tabs to backup file
  node iterm_control.js restore-tabs [file]     - Restore tabs from backup file
  node iterm_control.js close                   - Close current terminal window

Examples:
  node iterm_control.js open "Dev environment ready"
  node iterm_control.js execute "npm run dev"
  node iterm_control.js read
  node iterm_control.js write memo.txt "Hello World"
  echo "Large content" | node iterm_control.js write output.txt --stdin
  node iterm_control.js save-tabs
  node iterm_control.js save-tabs my_tabs.json
  node iterm_control.js restore-tabs
  node iterm_control.js restore-tabs my_tabs.json
  node iterm_control.js close
      `);
      break;
  }
}

// Export functions for use as a module
export {
  openTerminal,
  executeCommand,
  closeTerminal,
  getSessionText,
  writeFile,
  saveTabs,
  restoreTabs,
  executeITermScript
};

// Run CLI if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error("Fatal error:", error);
    process.exit(1);
  });
}
